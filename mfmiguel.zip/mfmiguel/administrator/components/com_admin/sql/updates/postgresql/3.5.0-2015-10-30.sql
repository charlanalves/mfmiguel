UPDATE "#__menu" SET "title" = 'com_contact_contacts' WHERE "id" = 8;
